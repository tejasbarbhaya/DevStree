//
//  ViewController.swift
//  DevStreeTest
//
//  Created by Tejash on 15/12/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        getNewsDetails()
    }

    func getNewsDetails() {
        Model.shared.getLastUpdateData(withCompletion: { [self] (response, errorMessage) in
            if let errorMessage = errorMessage {
                //self.showAlert(title: "error returned", message: errorMessage)
            }
            else if let response = response {
                print("response:: \(response)")
            }
        })
    }
}

