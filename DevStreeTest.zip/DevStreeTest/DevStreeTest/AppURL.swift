//
//  AppURL.swift
//  DevStreeTest
//
//  Created by Tejash on 15/12/21.
//

import Foundation
struct APPURL {
    private struct Domains {
        static let Dev = "https://private-ba0842-gary23.apiary-mock.com/notes"
    }
    
    
    private static let BaseURL = Domains.Dev
    
    static var getMainNews: String {
        return BaseURL + ""
    }
}
