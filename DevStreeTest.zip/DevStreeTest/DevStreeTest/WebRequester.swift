//
//  WebRequester.swift
//  DevStreeTest
//
//  Created by Tejash on 15/12/21.
//

import Foundation
import Alamofire

class WebRequester {
    
    static let shared = WebRequester()
    
    func request(toURL url: String, withParameters param: Parameters?, alongWithcompletion completion: @escaping (_ result: [String: Any]?, _ error: Error?) -> Void) {
        AF.request(url, method: .post, parameters: param)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseJSON { response in
                switch response.result {
                    case .success:
                        completion(response.value as? [String: Any], nil)
                    case let .failure(error):
                        completion(nil, error)
                }
        }
        .responseString { response in
            print("==============================")
            print("Response Time:\(String(describing: response.metrics?.taskInterval))")
            print("URL: \(url)")
            print("param: \(String(describing: param))")
            print("Response String: \(response.value ?? "Something went wrong")")
            print("==============================")
        }
    }
}
