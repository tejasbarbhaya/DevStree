//
//  Model.swift
//  DevStreeTest
//
//  Created by Tejash on 15/12/21.
//

import Foundation
import UIKit

class Model {
    static let shared = Model()
    
    //MARK: - API Calls
    func getLastUpdateData(withCompletion completion: @escaping (_ message: String?,_ errorMessage: String?) -> Void) {
        WebRequester.shared.request(toURL: APPURL.getMainNews, withParameters: nil) { (response, error) in
            if let error = error {
                completion(nil,error.localizedDescription)
            }
            else if let response = response {
                if let lastUpdateData = response["last_update_data"] as? String {
                    completion(lastUpdateData,nil)
                }
            }
            else {
                completion(nil,"data not found")
            }
        }
    }
}
